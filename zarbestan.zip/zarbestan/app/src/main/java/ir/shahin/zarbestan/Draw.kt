package ir.shahin.zarbestan

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import kotlin.math.cos
import kotlin.math.sin

/** رنگ‌های بازی (الهام از کاشی‌کاری و فیروزه‌ی ایرانی) */
object Pal {
    val NIGHT1 = 0xFF0A1442.toInt()
    val NIGHT2 = 0xFF22408F.toInt()
    val TURQ = 0xFF22D3C5.toInt()
    val TURQ_D = 0xFF0F8F86.toInt()
    val GOLD = 0xFFFFCB45.toInt()
    val GOLD_D = 0xFFD8961C.toInt()
    val RED = 0xFFE8465B.toInt()
    val RED_D = 0xFFA81F38.toInt()
    val GREEN = 0xFF42D987.toInt()
    val GREEN_D = 0xFF1F9B57.toInt()
    val PURPLE = 0xFF9461F0.toInt()
    val PURPLE_D = 0xFF5E36AE.toInt()
    val ORANGE = 0xFFFF8F40.toInt()
    val ORANGE_D = 0xFFC95A1B.toInt()
    val BLUE = 0xFF3D8BFF.toInt()
    val BLUE_D = 0xFF1F57B8.toInt()
    val CREAM = 0xFFFFF4DA.toInt()
    val SAND = 0xFFF5DBA4.toInt()
    val SAND_D = 0xFFD9AF64.toInt()
    val BROWN = 0xFF8B5A1B.toInt()
    val INK = 0xFF2B1B40.toInt()
    val GRAY = 0xFF8C93A8.toInt()
    val GRAY_D = 0xFF5F667A.toInt()
    val WHITE = 0xFFFFFFFF.toInt()
}

/** تبدیل ارقام انگلیسی به فارسی */
fun fa(n: Int): String {
    val sb = StringBuilder()
    for (ch in n.toString()) {
        if (ch in '0'..'9') sb.append('۰' + (ch - '0')) else sb.append(ch)
    }
    return sb.toString()
}

fun withAlpha(color: Int, a: Int): Int = (color and 0x00FFFFFF) or (a.coerceIn(0, 255) shl 24)

fun mix(a: Int, b: Int, t: Float): Int {
    val k = t.coerceIn(0f, 1f)
    return Color.argb(
        (Color.alpha(a) + (Color.alpha(b) - Color.alpha(a)) * k).toInt(),
        (Color.red(a) + (Color.red(b) - Color.red(a)) * k).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * k).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * k).toInt()
    )
}

/** ابزارهای نقاشی روی Canvas */
object Draw {
    private val fp = Paint(Paint.ANTI_ALIAS_FLAG)
    private val sp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeJoin = Paint.Join.ROUND
        strokeCap = Paint.Cap.ROUND
    }
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.DEFAULT_BOLD
        textAlign = Paint.Align.CENTER
    }
    private val rf = RectF()
    private val pth = Path()
    private val starUnit: Path = buildStar(8, 0.72f)

    private fun buildStar(n: Int, inner: Float): Path {
        val p = Path()
        for (i in 0 until n * 2) {
            val ang = Math.PI * i / n - Math.PI / 2
            val r = if (i % 2 == 0) 1f else inner
            val x = (cos(ang) * r).toFloat()
            val y = (sin(ang) * r).toFloat()
            if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
        }
        p.close()
        return p
    }

    fun rect(c: Canvas, l: Float, t: Float, r: Float, b: Float, rad: Float, color: Int) {
        fp.style = Paint.Style.FILL
        fp.color = color
        rf.set(l, t, r, b)
        c.drawRoundRect(rf, rad, rad, fp)
    }

    fun frame(c: Canvas, l: Float, t: Float, r: Float, b: Float, rad: Float, color: Int, w: Float) {
        sp.color = color
        sp.strokeWidth = w
        rf.set(l, t, r, b)
        c.drawRoundRect(rf, rad, rad, sp)
    }

    fun circle(c: Canvas, x: Float, y: Float, r: Float, color: Int) {
        fp.style = Paint.Style.FILL
        fp.color = color
        c.drawCircle(x, y, r, fp)
    }

    fun ring(c: Canvas, x: Float, y: Float, r: Float, color: Int, w: Float) {
        sp.color = color
        sp.strokeWidth = w
        c.drawCircle(x, y, r, sp)
    }

    fun arc(c: Canvas, cx: Float, cy: Float, r: Float, start: Float, sweep: Float, color: Int, w: Float) {
        sp.color = color
        sp.strokeWidth = w
        rf.set(cx - r, cy - r, cx + r, cy + r)
        c.drawArc(rf, start, sweep, false, sp)
    }

    fun line(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, color: Int, w: Float) {
        sp.color = color
        sp.strokeWidth = w
        c.drawLine(x1, y1, x2, y2, sp)
    }

    fun oval(c: Canvas, cx: Float, cy: Float, rx: Float, ry: Float, color: Int) {
        fp.style = Paint.Style.FILL
        fp.color = color
        rf.set(cx - rx, cy - ry, cx + rx, cy + ry)
        c.drawOval(rf, fp)
    }

    fun tri(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, x3: Float, y3: Float, color: Int) {
        pth.reset()
        pth.moveTo(x1, y1)
        pth.lineTo(x2, y2)
        pth.lineTo(x3, y3)
        pth.close()
        fp.style = Paint.Style.FILL
        fp.color = color
        c.drawPath(pth, fp)
    }

    fun star(c: Canvas, cx: Float, cy: Float, ro: Float, ri: Float, n: Int, rot: Float, color: Int) {
        pth.reset()
        val base = Math.toRadians(rot.toDouble())
        for (i in 0 until n * 2) {
            val a = base + Math.PI * i / n - Math.PI / 2
            val r = if (i % 2 == 0) ro else ri
            val x = cx + (cos(a) * r).toFloat()
            val y = cy + (sin(a) * r).toFloat()
            if (i == 0) pth.moveTo(x, y) else pth.lineTo(x, y)
        }
        pth.close()
        fp.style = Paint.Style.FILL
        fp.color = color
        c.drawPath(pth, fp)
    }

    /** ستاره‌ی هشت‌پر گره‌چینی (شمسه) */
    fun girih(c: Canvas, cx: Float, cy: Float, r: Float, rot: Float, color: Int, strokeW: Float) {
        c.save()
        c.translate(cx, cy)
        c.rotate(rot)
        c.scale(r, r)
        sp.color = color
        sp.strokeWidth = strokeW / r
        c.drawPath(starUnit, sp)
        c.scale(0.55f, 0.55f)
        c.rotate(22.5f)
        c.drawPath(starUnit, sp)
        c.restore()
    }

    fun heart(c: Canvas, cx: Float, cy: Float, size: Float, color: Int) {
        val w = size
        pth.reset()
        pth.moveTo(cx, cy + w * 0.45f)
        pth.cubicTo(cx - w * 0.78f, cy + w * 0.02f, cx - w * 0.55f, cy - w * 0.56f, cx, cy - w * 0.2f)
        pth.cubicTo(cx + w * 0.55f, cy - w * 0.56f, cx + w * 0.78f, cy + w * 0.02f, cx, cy + w * 0.45f)
        pth.close()
        fp.style = Paint.Style.FILL
        fp.color = color
        c.drawPath(pth, fp)
    }

    fun coin(c: Canvas, x: Float, y: Float, r: Float) {
        circle(c, x, y, r, Pal.GOLD_D)
        circle(c, x, y, r * 0.84f, Pal.GOLD)
        ring(c, x, y, r * 0.6f, Pal.GOLD_D, r * 0.12f)
        star(c, x, y, r * 0.38f, r * 0.17f, 5, 0f, Pal.GOLD_D)
    }

    /** نمای شهر: گنبد و دو مناره */
    fun dome(c: Canvas, cx: Float, by: Float, w: Float, col: Int, colD: Int) {
        rect(c, cx - w * 0.5f, by - w * 0.45f, cx + w * 0.5f, by, w * 0.04f, col)
        fp.style = Paint.Style.FILL
        fp.color = colD
        rf.set(cx - w * 0.4f, by - w * 0.85f, cx + w * 0.4f, by - w * 0.05f)
        c.drawArc(rf, 180f, 180f, true, fp)
        line(c, cx, by - w * 0.85f, cx, by - w * 1.02f, colD, w * 0.05f)
        circle(c, cx, by - w * 1.04f, w * 0.045f, colD)
        rect(c, cx - w * 0.1f, by - w * 0.28f, cx + w * 0.1f, by + w * 0.1f, w * 0.1f, colD)
        rect(c, cx - w * 0.64f, by - w * 0.8f, cx - w * 0.5f, by, w * 0.03f, col)
        rect(c, cx + w * 0.5f, by - w * 0.8f, cx + w * 0.64f, by, w * 0.03f, col)
        circle(c, cx - w * 0.57f, by - w * 0.82f, w * 0.08f, colD)
        circle(c, cx + w * 0.57f, by - w * 0.82f, w * 0.08f, colD)
    }

    fun lock(c: Canvas, cx: Float, cy: Float, w: Float, color: Int) {
        arc(c, cx, cy - w * 0.15f, w * 0.26f, 180f, 180f, color, w * 0.12f)
        line(c, cx - w * 0.26f, cy - w * 0.15f, cx - w * 0.26f, cy, color, w * 0.12f)
        line(c, cx + w * 0.26f, cy - w * 0.15f, cx + w * 0.26f, cy, color, w * 0.12f)
        rect(c, cx - w * 0.38f, cy, cx + w * 0.38f, cy + w * 0.6f, w * 0.1f, color)
    }

    fun text(
        c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int,
        shadow: Int = 0x66000000, align: Paint.Align = Paint.Align.CENTER
    ) {
        tp.textSize = size
        tp.textAlign = align
        val fm = tp.fontMetrics
        val by = y - (fm.ascent + fm.descent) / 2f
        if (shadow != 0) {
            tp.color = shadow
            c.drawText(s, x + size * 0.035f, by + size * 0.055f, tp)
        }
        tp.color = color
        c.drawText(s, x, by, tp)
    }

    fun textWidth(s: String, size: Float): Float {
        tp.textSize = size
        return tp.measureText(s)
    }

    /** اندازه‌ی فونتی که متن در عرض مجاز جا شود */
    fun fit(s: String, size: Float, maxW: Float): Float {
        val w = textWidth(s, size)
        return if (w > maxW) size * maxW / w else size
    }
}
