package ir.shahin.zarbestan

import android.content.Context
import android.content.SharedPreferences
import java.util.Collections
import java.util.Random
import kotlin.math.max
import kotlin.math.min

/** ذخیره‌ی پیشرفت بازی روی گوشی */
class Store(ctx: Context) {
    private val p: SharedPreferences = ctx.getSharedPreferences("zarbestan", Context.MODE_PRIVATE)

    var coins: Int
        get() = p.getInt("coins", 30)
        set(v) {
            p.edit().putInt("coins", max(0, v)).apply()
        }

    var sfx: Boolean
        get() = p.getBoolean("sfx", true)
        set(v) {
            p.edit().putBoolean("sfx", v).apply()
        }

    var music: Boolean
        get() = p.getBoolean("music", true)
        set(v) {
            p.edit().putBoolean("music", v).apply()
        }

    var blitzBest: Int
        get() = p.getInt("blitz_best", 0)
        set(v) {
            p.edit().putInt("blitz_best", v).apply()
        }

    var totalCorrect: Int
        get() = p.getInt("total_correct", 0)
        set(v) {
            p.edit().putInt("total_correct", v).apply()
        }

    var totalAnswered: Int
        get() = p.getInt("total_answered", 0)
        set(v) {
            p.edit().putInt("total_answered", v).apply()
        }

    fun stars(i: Int): Int = p.getInt("star_$i", 0)

    fun setStars(i: Int, v: Int) {
        if (v > stars(i)) p.edit().putInt("star_$i", v).apply()
    }

    private fun key(a: Int, b: Int) = "${min(a, b)}_${max(a, b)}"

    fun correct(a: Int, b: Int): Int = p.getInt("c_" + key(a, b), 0)
    fun wrong(a: Int, b: Int): Int = p.getInt("w_" + key(a, b), 0)

    fun record(a: Int, b: Int, ok: Boolean) {
        val k = key(a, b)
        val e = p.edit()
        if (ok) e.putInt("c_$k", correct(a, b) + 1) else e.putInt("w_$k", wrong(a, b) + 1)
        e.putInt("total_answered", totalAnswered + 1)
        if (ok) e.putInt("total_correct", totalCorrect + 1)
        e.apply()
    }
}

enum class QType { MC, MISSING, TF, TYPE }

class Question(
    val a: Int,
    val b: Int,
    val type: QType,
    /** پاسخ درست: حاصل ضرب (MC/TF/TYPE) یا عامل گمشده (MISSING) */
    val answer: Int,
    val options: IntArray,
    val correctIdx: Int,
    /** برای MISSING: ۰ یعنی a پنهان است، ۱ یعنی b پنهان است */
    val hidden: Int,
    val tfShown: Int,
    val tfTrue: Boolean,
    val timeLimit: Float
) {
    val disabled = BooleanArray(4)
    var used5050 = false
    val product: Int get() = a * b
}

/** تولید سؤال؛ سؤال‌هایی که بچه بیشتر اشتباه می‌کند بیشتر می‌آیند */
object Gen {
    private val rnd = Random()

    private fun weight(store: Store, a: Int, b: Int): Double {
        val c = store.correct(a, b)
        val w = store.wrong(a, b)
        if (c + w == 0) return 1.6
        return max(0.25, 1.0 + 2.5 * w - 0.35 * min(c, 5))
    }

    private fun pick(weights: DoubleArray): Int {
        var sum = 0.0
        for (x in weights) sum += x
        var r = rnd.nextDouble() * sum
        for (i in weights.indices) {
            r -= weights[i]
            if (r <= 0.0) return i
        }
        return weights.size - 1
    }

    private fun typeFor(mode: Int, level: Int, idx: Int, finisher: Boolean): QType {
        if (mode == 1) {
            return when (rnd.nextInt(6)) {
                0, 1, 2 -> QType.MC
                3, 4 -> QType.TF
                else -> QType.MISSING
            }
        }
        val adv = if (mode == 2) 4 else level
        return when {
            finisher && adv >= 1 -> QType.TYPE
            idx % 5 == 3 -> QType.TF
            idx % 5 == 1 && adv >= 1 -> QType.MISSING
            idx % 5 == 4 && adv >= 2 -> QType.TYPE
            else -> QType.MC
        }
    }

    private fun wrongProducts(a: Int, b: Int): List<Int> {
        val ans = a * b
        val cand = intArrayOf(
            (a + 1) * b, (a - 1) * b, a * (b + 1), a * (b - 1),
            ans + a, ans - a, ans + b, ans - b, ans + 10, ans - 10, ans + 1, ans - 1, ans + 2, ans - 2
        )
        val l = cand.filter { it > 0 && it != ans }.distinct().toMutableList()
        Collections.shuffle(l, rnd)
        var extra = 3
        while (l.size < 3) {
            if (ans + extra != ans && !l.contains(ans + extra)) l.add(ans + extra)
            extra++
        }
        return l
    }

    /**
     * mode: ۰ مرحله، ۱ مسابقه‌ی سریع، ۲ تمرین نقاط ضعف
     * session: شمارنده‌ی پاسخ‌های درست همین دور (برای تنوع)
     */
    fun make(
        mode: Int, level: Int, idx: Int, finisher: Boolean,
        store: Store, session: IntArray, recent: ArrayList<Int>
    ): Question {
        val pairs = ArrayList<IntArray>()
        if (mode == 0 && level in 0..7) {
            val t = level + 2
            for (b in 2..9) pairs.add(intArrayOf(t, b))
        } else {
            for (a in 2..9) for (b in a..9) pairs.add(intArrayOf(a, b))
        }
        val weights = DoubleArray(pairs.size)
        for (i in pairs.indices) {
            val a = pairs[i][0]
            val b = pairs[i][1]
            val key = min(a, b) * 10 + max(a, b)
            var w = weight(store, a, b)
            var k = 0
            while (k < session[key]) {
                w *= 0.35
                k++
            }
            if (recent.contains(key)) w *= 0.02
            if (mode == 2) w *= 1.0 + store.wrong(a, b) * 2.0
            weights[i] = max(w, 0.001)
        }
        val chosen = pairs[pick(weights)]
        var a = chosen[0]
        var b = chosen[1]
        if (a != b && rnd.nextBoolean()) {
            val tmp = a
            a = b
            b = tmp
        }
        val key = min(a, b) * 10 + max(a, b)
        recent.add(key)
        while (recent.size > 3) recent.removeAt(0)

        val type = typeFor(mode, level, idx, finisher)
        val ans = a * b
        val adv = if (mode == 2) 4 else level
        val base = when (type) {
            QType.MC -> 11f
            QType.MISSING -> 13f
            QType.TF -> 7f
            QType.TYPE -> 15f
        }
        val limit = if (mode == 1) 99f else max(base * 0.6f, base - adv * 0.35f)

        return when (type) {
            QType.MC -> {
                val opts = (wrongProducts(a, b).take(3) + ans).toMutableList()
                Collections.shuffle(opts, rnd)
                Question(a, b, type, ans, opts.toIntArray(), opts.indexOf(ans), 0, ans, true, limit)
            }
            QType.MISSING -> {
                val hidden = rnd.nextInt(2)
                val miss = if (hidden == 0) a else b
                val others = (2..9).filter { it != miss }.toMutableList()
                Collections.shuffle(others, rnd)
                val opts = (others.take(3) + miss).toMutableList()
                Collections.shuffle(opts, rnd)
                Question(a, b, type, miss, opts.toIntArray(), opts.indexOf(miss), hidden, ans, true, limit)
            }
            QType.TF -> {
                val isTrue = rnd.nextBoolean()
                val shown = if (isTrue) ans else wrongProducts(a, b)[0]
                Question(a, b, type, ans, IntArray(4), 0, 0, shown, isTrue, limit)
            }
            QType.TYPE -> Question(a, b, type, ans, IntArray(4), 0, 0, ans, true, limit)
        }
    }
}
