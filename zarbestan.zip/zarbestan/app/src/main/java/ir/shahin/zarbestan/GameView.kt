package ir.shahin.zarbestan

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** کل بازی روی یک View کشیده می‌شود: صفحه‌ها، انیمیشن‌ها، لمس و منطق */
class GameView(context: Context, private val store: Store, private val snd: SoundEngine) : View(context) {

    private enum class Screen { HOME, MAP, PLAY, RESULT, GRID, ABOUT }

    private class Hit(val id: String, val l: Float, val t: Float, val r: Float, val b: Float)

    private class Part(
        var x: Float, var y: Float, var vx: Float, var vy: Float, var age: Float,
        val life: Float, val color: Int, val size: Float, val kind: Int, var rot: Float, val vr: Float
    )

    private class FText(val text: String, var x: Float, var y: Float, var age: Float, val color: Int, val size: Float)

    // ------------------------------------------------------------ وضعیت کلی
    private var screen = Screen.HOME
    private var W = 0f
    private var H = 0f
    private var s = 1f
    private var tAll = 0f
    private var lastNs = 0L
    private var fade = 0f
    private val rnd = java.util.Random()
    private val hits = ArrayList<Hit>()
    private var pressedId: String? = null
    private val parts = ArrayList<Part>()
    private val ftexts = ArrayList<FText>()

    // ------------------------------------------------------------ وضعیت بازی
    private val maxHp = 10
    private var mode = 0 // ۰ مرحله، ۱ مسابقه‌ی سریع، ۲ تمرین نقاط ضعف
    private var level = 0
    private var hearts = 3
    private var score = 0
    private var combo = 0
    private var bestCombo = 0
    private var correctCount = 0
    private var askedCount = 0
    private var coinsEarned = 0
    private var monsterHp = 10
    private var cur: Question? = null
    private var phase = 0 // ۰ سؤال، ۱ بازخورد، ۲ پایان
    private var qLeft = 0f
    private var qMax = 1f
    private var fbTimer = 0f
    private var blitzLeft = 60f
    private var selected = -1
    private var typed = ""
    private var lastWasCorrect = false
    private var paused = false
    private var hurtT = 0f
    private var attackT = 0f
    private var deadT = 0f
    private var shake = 0f
    private var flashRed = 0f
    private var lastTickSec = -1
    private val session = IntArray(100)
    private val recent = ArrayList<Int>()
    private var endPending = 0
    private var endTimer = 0f

    // نتیجه
    private var resWin = false
    private var resStars = 0
    private var resScore = 0
    private var resCorrect = 0
    private var resCombo = 0
    private var resCoins = 0
    private var resNewBest = false
    private var resBest = 0
    private var resT = 0f
    private var starsShown = 0

    private var selectedNode = -1

    // ------------------------------------------------------------ چیدمان
    private var topPad = 0f
    private var hudCy = 0f
    private var nameCy = 0f
    private var barCy = 0f
    private var monR = 0f
    private var monCy = 0f
    private var timerCy = 0f
    private var cardTop = 0f
    private var cardH = 0f
    private var ansTop = 0f
    private var ansBottom = 0f
    private var powerTop = 0f
    private var powerH = 0f

    // ------------------------------------------------------------ منابع نقاشی
    private val shaders = arrayOfNulls<Shader>(11)
    private val bgPaint = Paint()
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dunePath = Path()

    private val skyTop = intArrayOf(
        0xFF0A1442.toInt(), 0xFFFBE6B0.toInt(), 0xFF0B2A5E.toInt(), 0xFF3B1C74.toInt(), 0xFF7A2E0E.toInt(),
        0xFF0E4D64.toInt(), 0xFF5C1A3B.toInt(), 0xFF16324F.toInt(), 0xFF3A0CA3.toInt(), 0xFF6A040F.toInt(),
        0xFF10002B.toInt()
    )
    private val skyBot = intArrayOf(
        0xFF3A2C86.toInt(), 0xFFE7B96A.toInt(), 0xFF1BA39C.toInt(), 0xFFD65DB1.toInt(), 0xFFF2994A.toInt(),
        0xFF4CC9F0.toInt(), 0xFFEF476F.toInt(), 0xFF7BD389.toInt(), 0xFF4895EF.toInt(), 0xFFFF9F1C.toInt(),
        0xFF9D4EDD.toInt()
    )
    private val optCols = intArrayOf(Pal.BLUE, Pal.ORANGE, Pal.PURPLE, Pal.TURQ)
    private val optColsD = intArrayOf(Pal.BLUE_D, Pal.ORANGE_D, Pal.PURPLE_D, Pal.TURQ_D)
    private val goldColors = intArrayOf(Pal.GOLD, Pal.ORANGE, Pal.CREAM)
    private val confettiColors = intArrayOf(Pal.RED, Pal.GOLD, Pal.TURQ, Pal.PURPLE, Pal.GREEN, Pal.BLUE, Pal.ORANGE)
    private val praise = arrayOf("آفرین!", "عالی!", "دمت گرم!", "بی‌نظیر!", "درسته!", "ایول!")

    private val nx = floatArrayOf(0.28f, 0.70f, 0.30f, 0.70f, 0.32f, 0.68f, 0.30f, 0.70f, 0.50f)
    private val ny = floatArrayOf(0.93f, 0.82f, 0.71f, 0.60f, 0.49f, 0.38f, 0.27f, 0.16f, 0.05f)
    private val cityNames = arrayOf("شیراز", "اصفهان", "یزد", "تبریز", "کاشان", "رشت", "کرمان", "مشهد", "تخت‌جمشید")

    private val black = 0xFF000000.toInt()

    // ------------------------------------------------------------ چرخه‌ی حیات
    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        for (i in shaders.indices) shaders[i] = null
    }

    fun handleBack(): Boolean {
        when (screen) {
            Screen.HOME -> return false
            Screen.PLAY -> {
                if (phase != 2) {
                    paused = !paused
                    snd.play("click")
                }
            }
            Screen.RESULT -> go(if (mode == 0) Screen.MAP else Screen.HOME)
            Screen.MAP -> {
                if (selectedNode >= 0) selectedNode = -1 else go(Screen.HOME)
            }
            else -> go(Screen.HOME)
        }
        return true
    }

    fun onPauseGame() {
        if (screen == Screen.PLAY && phase != 2) paused = true
    }

    fun onResumeGame() {
        lastNs = 0L
        invalidate()
    }

    private fun go(sc: Screen) {
        screen = sc
        fade = 1f
        selectedNode = -1
        pressedId = null
        if (sc == Screen.RESULT) {
            resT = 0f
            starsShown = 0
        }
    }

    // ------------------------------------------------------------ لمس
    private fun hitAt(x: Float, y: Float): String? {
        for (i in hits.indices.reversed()) {
            val h = hits[i]
            if (x >= h.l && x <= h.r && y >= h.t && y <= h.b) return h.id
        }
        return null
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> pressedId = hitAt(e.x, e.y)
            MotionEvent.ACTION_MOVE -> {
                if (pressedId != null && hitAt(e.x, e.y) != pressedId) pressedId = null
            }
            MotionEvent.ACTION_UP -> {
                val id = hitAt(e.x, e.y)
                val p = pressedId
                pressedId = null
                if (id != null && id == p) onTap(id)
            }
            MotionEvent.ACTION_CANCEL -> pressedId = null
        }
        return true
    }

    private fun onTap(id: String) {
        if (screen == Screen.PLAY) {
            playTap(id)
            return
        }
        snd.play("click")
        when (id) {
            "h_adv" -> go(Screen.MAP)
            "h_blitz" -> startRun(1, 0)
            "h_grid" -> go(Screen.GRID)
            "h_about" -> go(Screen.ABOUT)
            "t_music" -> {
                store.music = !store.music
                snd.musicOn = store.music
            }
            "t_sfx" -> {
                store.sfx = !store.sfx
                snd.sfxOn = store.sfx
            }
            "back" -> handleBack()
            "start" -> {
                val i = selectedNode
                if (i >= 0) startRun(0, i)
            }
            "close_card" -> selectedNode = -1
            "locked" -> snd.play("wrong")
            "r_next" -> startRun(0, level + 1)
            "r_again" -> startRun(mode, level)
            "r_back" -> go(if (mode == 0) Screen.MAP else Screen.HOME)
            "weak" -> startRun(2, 0)
            else -> {
                if (id.startsWith("node")) selectedNode = id.substring(4).toInt()
            }
        }
    }

    private fun playTap(id: String) {
        when (id) {
            "pause" -> {
                if (phase != 2) {
                    paused = true
                    snd.play("click")
                }
                return
            }
            "resume" -> {
                paused = false
                snd.play("click")
                return
            }
            "restart" -> {
                snd.play("click")
                startRun(mode, level)
                return
            }
            "quit" -> {
                snd.play("click")
                paused = false
                go(if (mode == 0) Screen.MAP else Screen.HOME)
                return
            }
        }
        if (paused) return
        val q = cur ?: return
        if (phase != 0) return
        when {
            id.startsWith("opt") -> {
                val i = id.substring(3).toInt()
                if (!q.disabled[i]) {
                    selected = i
                    resolve(i == q.correctIdx, false)
                }
            }
            id == "tf1" || id == "tf0" -> {
                val v = id == "tf1"
                selected = if (v) 1 else 0
                resolve(v == q.tfTrue, false)
            }
            id.startsWith("key") -> {
                val d = id.substring(3).toInt()
                if (typed.length < 2 && !(typed.isEmpty() && d == 0)) {
                    typed += d.toString()
                    snd.play("click")
                }
            }
            id == "del" -> {
                if (typed.isNotEmpty()) typed = typed.dropLast(1)
                snd.play("click")
            }
            id == "ok" -> {
                if (typed.isNotEmpty()) {
                    val v = typed.toInt()
                    selected = v
                    resolve(v == q.answer, false)
                }
            }
            id == "pw5050" -> use5050()
            id == "pwtime" -> useTime()
        }
    }

    // ------------------------------------------------------------ منطق بازی
    private fun monIdx(): Int = when (mode) {
        0 -> level
        2 -> 9
        else -> 0
    }

    private fun startRun(m: Int, lv: Int) {
        mode = m
        level = lv
        hearts = 3
        score = 0
        combo = 0
        bestCombo = 0
        correctCount = 0
        askedCount = 0
        coinsEarned = 0
        monsterHp = maxHp
        blitzLeft = 60f
        paused = false
        deadT = 0f
        hurtT = 0f
        attackT = 0f
        shake = 0f
        flashRed = 0f
        endPending = 0
        java.util.Arrays.fill(session, 0)
        recent.clear()
        parts.clear()
        ftexts.clear()
        go(Screen.PLAY)
        nextQuestion()
        snd.play("whoosh")
    }

    private fun nextQuestion() {
        val q = Gen.make(mode, level, askedCount, mode != 1 && monsterHp == 1, store, session, recent)
        cur = q
        askedCount++
        qMax = q.timeLimit
        qLeft = qMax
        phase = 0
        selected = -1
        typed = ""
        lastTickSec = -1
    }

    private fun resolve(ok: Boolean, timeout: Boolean) {
        val q = cur ?: return
        phase = 1
        lastWasCorrect = ok
        store.record(q.a, q.b, ok)
        val key = min(q.a, q.b) * 10 + max(q.a, q.b)
        val cx = W / 2f
        if (ok) {
            combo++
            if (combo > bestCombo) bestCombo = combo
            session[key]++
            correctCount++
            val timeBonus = if (qMax < 90f) (qLeft * 2f).toInt() else 5
            val gain = 10 + timeBonus + max(0, combo - 2) * 5
            score += gain
            val coinGain = if (combo >= 5) 3 else if (combo >= 3) 2 else 1
            store.coins = store.coins + coinGain
            coinsEarned += coinGain
            snd.play("correct")
            snd.play("coin")
            ftexts.add(FText("+${fa(gain)}", cx, cardTop - 10f * s, 0f, Pal.GOLD, 76f * s))
            ftexts.add(FText(praise[rnd.nextInt(praise.size)], cx, monCy, 0f, Pal.GREEN, 82f * s))
            if (combo >= 3) {
                ftexts.add(FText("کومبو ${fa(combo)}", cx, timerCy, 0f, Pal.ORANGE, 64f * s))
            }
            burst(cx, cardTop + cardH * 0.5f, 16, 3, 700f * s, goldColors)
            if (mode != 1) {
                monsterHp -= 1
                hurtT = 1f
                snd.play("hit")
                burst(cx, monCy, 14, 1, 800f * s, confettiColors)
                if (monsterHp <= 0) {
                    phase = 2
                    endPending = 1
                    endTimer = 2.0f
                    deadT = 0f
                    snd.play("boom")
                    burst(cx, monCy, 60, 1, 1200f * s, confettiColors)
                    shake = 1f
                    return
                }
                fbTimer = 0.95f
            } else {
                fbTimer = 0.45f
            }
        } else {
            combo = 0
            snd.play("wrong")
            shake = 1f
            flashRed = 1f
            vibrate(120)
            ftexts.add(FText(if (timeout) "وقت تمام شد!" else "اشتباه شد!", cx, monCy, 0f, Pal.RED, 78f * s))
            if (mode == 1) {
                blitzLeft = max(0f, blitzLeft - 4f)
                ftexts.add(FText("−${fa(4)} ثانیه", cx, timerCy, 0f, Pal.RED, 56f * s))
                fbTimer = 0.9f
            } else {
                hearts--
                attackT = 1f
                fbTimer = 1.7f
                if (hearts <= 0) {
                    phase = 2
                    endPending = 2
                    endTimer = 1.6f
                }
            }
        }
    }

    private fun use5050() {
        val q = cur ?: return
        if (phase != 0) return
        if (q.type != QType.MC && q.type != QType.MISSING) return
        if (q.used5050 || store.coins < 15) return
        store.coins = store.coins - 15
        q.used5050 = true
        val wrongIdx = (0..3).filter { it != q.correctIdx }.shuffled()
        q.disabled[wrongIdx[0]] = true
        q.disabled[wrongIdx[1]] = true
        snd.play("power")
    }

    private fun useTime() {
        if (phase != 0 || store.coins < 10) return
        store.coins = store.coins - 10
        if (mode == 1) {
            blitzLeft += 6f
        } else {
            qLeft += 6f
            qMax = max(qMax, qLeft)
        }
        snd.play("power")
        ftexts.add(FText("+${fa(6)} ثانیه", W / 2f, timerCy, 0f, Pal.TURQ, 56f * s))
    }

    private fun finishRun(win: Boolean) {
        resWin = win
        resScore = score
        resCorrect = correctCount
        resCombo = bestCombo
        if (win) {
            resStars = hearts.coerceIn(1, 3)
            val bonus = 10 * resStars
            store.coins = store.coins + bonus
            coinsEarned += bonus
            if (mode == 0) store.setStars(level, resStars)
            snd.play("win")
        } else {
            resStars = 0
            snd.play("lose")
        }
        resCoins = coinsEarned
        go(Screen.RESULT)
    }

    private fun finishBlitz() {
        resWin = true
        resStars = 0
        resScore = score
        resCorrect = correctCount
        resCombo = bestCombo
        val bonus = correctCount / 2
        store.coins = store.coins + bonus
        coinsEarned += bonus
        resCoins = coinsEarned
        resNewBest = score > store.blitzBest
        if (resNewBest) store.blitzBest = score
        resBest = store.blitzBest
        snd.play("win")
        go(Screen.RESULT)
    }

    @Suppress("DEPRECATION")
    private fun vibrate(ms: Long) {
        try {
            val v = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
            if (Build.VERSION.SDK_INT >= 26) {
                v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                v.vibrate(ms)
            }
        } catch (e: Throwable) {
        }
    }

    // ------------------------------------------------------------ به‌روزرسانی
    private fun burst(x: Float, y: Float, n: Int, kind: Int, speed: Float, colors: IntArray) {
        if (parts.size > 360) return
        for (k in 0 until n) {
            val a = rnd.nextFloat() * 6.2832f
            val v = speed * (0.35f + rnd.nextFloat() * 0.8f)
            parts.add(
                Part(
                    x, y, cos(a) * v, sin(a) * v - speed * 0.3f, 0f,
                    0.8f + rnd.nextFloat() * 0.7f, colors[rnd.nextInt(colors.size)],
                    (10f + rnd.nextFloat() * 16f) * s, kind, rnd.nextFloat() * 360f,
                    (rnd.nextFloat() - 0.5f) * 600f
                )
            )
        }
    }

    private fun update(dt: Float) {
        var i = parts.size - 1
        while (i >= 0) {
            val p = parts[i]
            p.age += dt
            p.vy += (if (p.kind == 2) 350f else 1700f) * s * dt
            p.x += p.vx * dt
            p.y += p.vy * dt
            p.rot += p.vr * dt
            if (p.age >= p.life) parts.removeAt(i)
            i--
        }
        i = ftexts.size - 1
        while (i >= 0) {
            val f = ftexts[i]
            f.age += dt
            f.y -= 90f * s * dt
            if (f.age >= 1.2f) ftexts.removeAt(i)
            i--
        }
        hurtT = max(0f, hurtT - dt * 3.2f)
        attackT = max(0f, attackT - dt * 2.2f)
        shake = max(0f, shake - dt * 3f)
        flashRed = max(0f, flashRed - dt * 2.2f)

        if (screen == Screen.PLAY) updatePlay(dt)
        if (screen == Screen.RESULT) {
            resT += dt
            if (mode != 1 && resWin) {
                while (starsShown < resStars && resT > 0.7f + 0.5f * starsShown) {
                    val sx = W / 2f + (starsShown - 1) * 230f * s
                    starsShown++
                    snd.play("star")
                    burst(sx, H * 0.255f, 12, 1, 700f * s, goldColors)
                }
            }
            if (resWin && rnd.nextFloat() < dt * 14f) {
                parts.add(
                    Part(
                        rnd.nextFloat() * W, -20f * s, (rnd.nextFloat() - 0.5f) * 200f * s,
                        (150f + rnd.nextFloat() * 200f) * s, 0f, 4f,
                        confettiColors[rnd.nextInt(confettiColors.size)], 18f * s, 2,
                        rnd.nextFloat() * 360f, (rnd.nextFloat() - 0.5f) * 500f
                    )
                )
            }
        }
    }

    private fun updatePlay(dt: Float) {
        if (paused) return
        when (phase) {
            0 -> {
                if (mode == 1) {
                    blitzLeft -= dt
                    if (blitzLeft <= 5f && blitzLeft > 0f) {
                        val sec = ceil(blitzLeft).toInt()
                        if (sec != lastTickSec) {
                            lastTickSec = sec
                            snd.play("tick")
                        }
                    }
                    if (blitzLeft <= 0f) {
                        blitzLeft = 0f
                        phase = 2
                        endPending = 3
                        endTimer = 0.9f
                        ftexts.add(FText("تمام شد!", W / 2f, monCy, 0f, Pal.GOLD, 100f * s))
                        snd.play("star")
                    }
                } else {
                    qLeft -= dt
                    if (qLeft <= 3f && qLeft > 0f) {
                        val sec = ceil(qLeft).toInt()
                        if (sec != lastTickSec) {
                            lastTickSec = sec
                            snd.play("tick")
                        }
                    }
                    if (qLeft <= 0f) {
                        qLeft = 0f
                        resolve(false, true)
                    }
                }
            }
            1 -> {
                fbTimer -= dt
                if (fbTimer <= 0f) nextQuestion()
            }
            2 -> {
                endTimer -= dt
                if (endPending == 1) deadT = min(1f, deadT + dt * 0.75f)
                if (endTimer <= 0f) {
                    val e = endPending
                    endPending = 0
                    when (e) {
                        1 -> finishRun(true)
                        2 -> finishRun(false)
                        3 -> finishBlitz()
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------ نقاشی کلی
    override fun onDraw(c: Canvas) {
        if (width == 0 || height == 0) {
            postInvalidateOnAnimation()
            return
        }
        val now = System.nanoTime()
        val dt = if (lastNs == 0L) 0.016f else ((now - lastNs) / 1_000_000_000f).coerceIn(0f, 0.05f)
        lastNs = now
        tAll += dt
        W = width.toFloat()
        H = height.toFloat()
        s = W / 1080f
        calcLayout()
        hits.clear()
        update(dt)
        when (screen) {
            Screen.HOME -> drawHome(c)
            Screen.MAP -> drawMap(c)
            Screen.PLAY -> drawPlay(c)
            Screen.RESULT -> drawResult(c)
            Screen.GRID -> drawGrid(c)
            Screen.ABOUT -> drawAbout(c)
        }
        drawFx(c)
        if (flashRed > 0f) c.drawColor(withAlpha(Pal.RED, (flashRed * 90f).toInt()))
        if (fade > 0f) {
            c.drawColor(withAlpha(Pal.NIGHT1, (fade * 255f).toInt()))
            fade = max(0f, fade - dt * 2.8f)
        }
        postInvalidateOnAnimation()
    }

    private fun calcLayout() {
        topPad = 64f * s
        hudCy = topPad + 55f * s
        nameCy = hudCy + 95f * s
        barCy = nameCy + 55f * s
        monR = min(230f * s, H * 0.1f)
        monCy = barCy + 40f * s + monR * 1.5f
        timerCy = monCy + monR + 62f * s
        cardTop = timerCy + 36f * s
        cardH = 230f * s
        ansTop = cardTop + cardH + 44f * s
        powerH = 112f * s
        powerTop = H - 64f * s - powerH
        ansBottom = powerTop - 30f * s
    }

    private fun drawBackground(c: Canvas, theme: Int) {
        val th = theme.coerceIn(0, 10)
        var sh = shaders[th]
        if (sh == null) {
            sh = LinearGradient(0f, 0f, 0f, H, skyTop[th], skyBot[th], Shader.TileMode.CLAMP)
            shaders[th] = sh
        }
        bgPaint.shader = sh
        c.drawRect(0f, 0f, W, H, bgPaint)

        // الگوی شمسه‌های گره‌چینی که آرام حرکت می‌کنند
        val sp = 280f * s
        val rowH = sp * 0.866f
        val period = rowH * 2f
        val off = (tAll * 14f * s) % period
        val pc = if (th == 1) withAlpha(Pal.BROWN, 38) else withAlpha(Pal.WHITE, 20)
        var y = -period + off
        var row = 0
        while (y < H + sp) {
            var x = -sp + (if (row % 2 == 0) 0f else sp / 2f)
            while (x < W + sp) {
                Draw.girih(c, x, y, 92f * s, 0f, pc, 3f * s)
                x += sp
            }
            y += rowH
            row++
        }
        // ستاره‌های شب
        if (th != 1) {
            for (i in 0 until 34) {
                val sx = ((i * 7919) % 1000) / 1000f * W
                val sy = ((i * 6007) % 1000) / 1000f * H * 0.6f
                val tw = 0.5f + 0.5f * sin(tAll * (1.2f + (i % 5) * 0.4f) + i)
                Draw.circle(c, sx, sy, (2f + (i % 3)) * s, withAlpha(Pal.WHITE, (60 + 150 * tw).toInt()))
            }
        }
        // عددهای شناور
        val dc = withAlpha(if (th == 1) Pal.BROWN else Pal.WHITE, 30)
        for (i in 0 until 12) {
            val speed = (28f + (i % 5) * 11f) * s
            val fx = ((i * 337 + 91) % 1000) / 1000f * W
            val fy = H + 120f * s - ((tAll * speed + i * 211f * s) % (H + 240f * s))
            val sz = (54f + (i % 4) * 22f) * s
            Draw.text(c, if (i % 3 == 0) "×" else fa(2 + i % 8), fx + sin(tAll * 0.6f + i) * 26f * s, fy, sz, dc, 0)
        }
    }

    private fun btn(
        c: Canvas, id: String, l: Float, t: Float, r: Float, b: Float, label: String,
        col: Int, colD: Int, size: Float, enabled: Boolean = true, labelDx: Float = 0f
    ) {
        val pressed = enabled && pressedId == id
        val depth = 14f * s
        val dy = if (pressed) depth * 0.7f else 0f
        val rad = min((b - t) * 0.28f, 40f * s)
        Draw.rect(c, l, t + depth, r, b, rad, colD)
        Draw.rect(c, l, t + dy, r, b - depth + dy, rad, col)
        Draw.rect(c, l + 10f * s, t + dy + 8f * s, r - 10f * s, t + dy + (b - t - depth) * 0.45f, rad * 0.8f, withAlpha(Pal.WHITE, 55))
        if (label.isNotEmpty()) {
            val maxW = (r - l) * 0.9f - abs(labelDx) * 2f
            Draw.text(c, label, (l + r) / 2f + labelDx, (t + b - depth) / 2f + dy, Draw.fit(label, size, maxW), Pal.WHITE)
        }
        if (enabled) hits.add(Hit(id, l, t, r, b))
    }

    private fun chip(c: Canvas, id: String, cx: Float, cy: Float, w: Float, label: String, on: Boolean) {
        val h = 74f * s
        btn(
            c, id, cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f + 14f * s, label,
            if (on) Pal.GREEN else Pal.GRAY, if (on) Pal.GREEN_D else Pal.GRAY_D, 32f * s
        )
    }

    private fun coinPill(c: Canvas, rightX: Float, cy: Float) {
        val w = 250f * s
        val h = 74f * s
        Draw.rect(c, rightX - w, cy - h / 2f, rightX, cy + h / 2f, h / 2f, withAlpha(black, 110))
        Draw.coin(c, rightX - w + 40f * s, cy, 28f * s)
        Draw.text(c, fa(store.coins), (rightX - w + 75f * s + rightX - 15f * s) / 2f, cy, 44f * s, Pal.GOLD)
    }

    private fun backButton(c: Canvas) {
        btn(c, "back", 30f * s, topPad + 8f * s, 270f * s, topPad + 112f * s + 14f * s, "بازگشت", Pal.BLUE, Pal.BLUE_D, 40f * s)
    }

    // ------------------------------------------------------------ صفحه‌ی اصلی
    private fun duneY(x: Float, base: Float, amp: Float, freq: Float, ph: Float): Float =
        base + sin(x / s * freq + ph) * amp * s

    private fun fillDune(c: Canvas, base: Float, amp: Float, freq: Float, ph: Float, color: Int) {
        dunePath.reset()
        dunePath.moveTo(0f, H)
        var x = 0f
        while (x <= W + 40f * s) {
            dunePath.lineTo(x, duneY(x, base, amp, freq, ph))
            x += 36f * s
        }
        dunePath.lineTo(W + 40f * s, H)
        dunePath.close()
        fillPaint.shader = null
        fillPaint.style = Paint.Style.FILL
        fillPaint.color = color
        c.drawPath(dunePath, fillPaint)
    }

    private fun drawHome(c: Canvas) {
        drawBackground(c, 0)
        val cx = W / 2f
        // ماه
        Draw.circle(c, W * 0.84f, H * 0.17f, 92f * s, withAlpha(0xFFFFE9A8.toInt(), 40))
        Draw.circle(c, W * 0.84f, H * 0.17f, 66f * s, 0xFFFFE9A8.toInt())
        // عنوان
        Draw.girih(c, cx, H * 0.255f, 470f * s, tAll * 5f, withAlpha(Pal.GOLD, 90), 5f * s)
        Draw.girih(c, cx, H * 0.255f, 370f * s, -tAll * 7f, withAlpha(Pal.TURQ, 90), 4f * s)
        val title = "ضرب‌ستان"
        Draw.text(c, title, cx, H * 0.245f, Draw.fit(title, 200f * s, 840f * s), Pal.GOLD, Pal.ORANGE_D)
        Draw.text(c, "ماجراجویی جدول ضرب", cx, H * 0.245f + 150f * s, 56f * s, Pal.CREAM)

        // تپه‌های شنی و کاروان
        val b1 = H * 0.50f
        fillDune(c, b1, 38f, 0.004f, 1f, 0xFF2B2468.toInt())
        val camX = (tAll * 55f * s) % (W + 500f * s) - 250f * s
        Art.camel(c, camX, duneY(camX, b1, 38f, 0.004f, 1f) + 8f * s, 0.5f * s, tAll, true, false)
        fillDune(c, H * 0.545f, 44f, 0.0035f, 3f, 0xFF3B2F85.toInt())

        // دکمه‌ها
        val pulse = 1f + 0.012f * sin(tAll * 3f)
        val bw = 800f * s
        val bh = 140f * s
        val gap = 28f * s
        var y0 = H * 0.60f
        btn(c, "h_adv", cx - bw * pulse / 2f, y0, cx + bw * pulse / 2f, y0 + bh, "ماجراجویی", Pal.GREEN, Pal.GREEN_D, 64f * s)
        y0 += bh + gap
        btn(c, "h_blitz", cx - bw / 2f, y0, cx + bw / 2f, y0 + bh, "مسابقه‌ی ${fa(60)} ثانیه", Pal.ORANGE, Pal.ORANGE_D, 58f * s)
        y0 += bh + gap
        btn(c, "h_grid", cx - bw / 2f, y0, cx + bw / 2f, y0 + bh, "دفتر مشق", Pal.PURPLE, Pal.PURPLE_D, 58f * s)
        y0 += bh + gap
        btn(c, "h_about", cx - bw / 2f, y0, cx + bw / 2f, y0 + bh, "طراح و سازنده", Pal.TURQ, Pal.TURQ_D, 58f * s)

        // نوار بالا
        chip(c, "t_music", 30f * s + 130f * s, topPad + 40f * s, 260f * s, "موسیقی", store.music)
        chip(c, "t_sfx", 30f * s + 130f * s + 280f * s, topPad + 40f * s, 260f * s, "جلوه‌ها", store.sfx)
        coinPill(c, W - 30f * s, topPad + 40f * s)

        Draw.text(c, "طراح و سازنده: شاهین شیخ کانلو", cx, H - 56f * s, 38f * s, withAlpha(Pal.CREAM, 200), 0)
    }

    // ------------------------------------------------------------ نقشه‌ی سفر
    private fun nodeX(i: Int): Float = W * nx[i]
    private fun nodeY(i: Int): Float = H * (0.19f + 0.70f * ny[i])
    private fun unlocked(i: Int): Boolean = i == 0 || store.stars(i - 1) >= 1
    private fun currentNode(): Int {
        for (i in 0..8) if (store.stars(i) == 0) return i
        return 8
    }

    private fun drawMap(c: Canvas) {
        drawBackground(c, 1)
        Draw.text(c, "نقشه‌ی سفر", W / 2f, topPad + 60f * s, 76f * s, Pal.BROWN, 0x33FFFFFF)
        backButton(c)
        coinPill(c, W - 30f * s, topPad + 60f * s)

        // مسیر نقطه‌چین بین شهرها
        for (i in 0 until 8) {
            val x0 = nodeX(i)
            val y0 = nodeY(i)
            val x1 = nodeX(i + 1)
            val y1 = nodeY(i + 1)
            val ym = (y0 + y1) / 2f
            val open = unlocked(i + 1)
            for (k in 1..13) {
                val t = k / 14f
                val u = 1f - t
                val px = u * u * u * x0 + 3f * u * u * t * x0 + 3f * u * t * t * x1 + t * t * t * x1
                val py = u * u * u * y0 + 3f * u * u * t * ym + 3f * u * t * t * ym + t * t * t * y1
                Draw.circle(c, px, py, (if (open) 9f else 7f) * s, if (open) Pal.GOLD_D else withAlpha(Pal.BROWN, 140))
            }
        }

        val curN = currentNode()
        for (i in 0..8) {
            val x = nodeX(i)
            val y = nodeY(i)
            val open = unlocked(i)
            val r = (if (i == 8) 86f else 72f) * s
            if (i == curN) {
                Draw.ring(c, x, y, r + 14f * s + sin(tAll * 4f) * 8f * s, withAlpha(Pal.GOLD_D, 220), 8f * s)
            }
            Draw.circle(c, x, y + 8f * s, r, withAlpha(black, 50))
            Draw.circle(c, x, y, r, if (open) Pal.TURQ_D else Pal.GRAY_D)
            Draw.circle(c, x, y, r - 8f * s, if (open) Pal.TURQ else Pal.GRAY)
            Draw.ring(c, x, y, r, if (open) Pal.GOLD else Pal.GRAY_D, 7f * s)
            if (open) Draw.dome(c, x, y + r * 0.35f, r, Pal.CREAM, Pal.GOLD_D) else Draw.lock(c, x, y - r * 0.1f, r * 0.9f, Pal.CREAM)
            val st = store.stars(i)
            for (k in 0..2) {
                Draw.star(
                    c, x + (k - 1) * r * 0.62f, y - r - 26f * s + (if (k == 1) -10f * s else 0f),
                    20f * s, 9f * s, 5, 0f, if (k < st) Pal.GOLD else withAlpha(Pal.BROWN, 90)
                )
            }
            Draw.text(c, cityNames[i], x, y + r + 40f * s, 42f * s, Pal.INK, 0x44FFFFFF)
            hits.add(Hit(if (open) "node$i" else "locked", x - r, y - r - 44f * s, x + r, y + r + 70f * s))
        }

        // شتر کاروان کنار شهر فعلی
        val nodeRight = nx[curN] > 0.5f
        val camX = nodeX(curN) + (if (nodeRight) -200f else 200f) * s
        Art.camel(c, camX, nodeY(curN) + 70f * s, 0.36f * s, tAll, true, !nodeRight)

        if (selectedNode >= 0) drawNodeCard(c)
    }

    private fun drawNodeCard(c: Canvas) {
        hits.clear()
        c.drawColor(withAlpha(black, 150))
        val i = selectedNode
        val l = 80f * s
        val r = W - 80f * s
        val t = H * 0.5f - 480f * s
        val b = H * 0.5f + 480f * s
        Draw.rect(c, l, t + 14f * s, r, b + 14f * s, 50f * s, withAlpha(black, 80))
        Draw.rect(c, l, t, r, b, 50f * s, Pal.CREAM)
        Draw.frame(c, l + 14f * s, t + 14f * s, r - 14f * s, b - 14f * s, 40f * s, Pal.GOLD, 8f * s)
        Draw.text(c, cityNames[i], W / 2f, t + 100f * s, 84f * s, Pal.INK, 0x22000000)
        val sub = if (i < 8) "جدول ضرب ${fa(i + 2)}" else "همه‌ی جدول‌ها"
        Draw.text(c, sub, W / 2f, t + 185f * s, 54f * s, Pal.TURQ_D, 0)
        Art.monster(c, W / 2f, t + 420f * s, 120f * s, i, tAll, 0f, 0f, 0f)
        Draw.text(c, Art.monsterNames[i], W / 2f, t + 600f * s, 52f * s, Pal.RED_D, 0)
        val st = store.stars(i)
        for (k in 0..2) {
            Draw.star(
                c, W / 2f + (k - 1) * 110f * s, t + 668f * s + (if (k == 1) -12f * s else 0f),
                44f * s, 20f * s, 5, 0f, if (k < st) Pal.GOLD else withAlpha(Pal.BROWN, 90)
            )
        }
        btn(c, "start", l + 70f * s, b - 240f * s, r - 70f * s, b - 90f * s, "شروع ماجراجویی", Pal.GREEN, Pal.GREEN_D, 56f * s)
        btn(c, "close_card", r - 150f * s, t + 30f * s, r - 40f * s, t + 140f * s, "", Pal.RED, Pal.RED_D, 10f)
        val xc = r - 95f * s
        val xy = t + 70f * s
        Draw.line(c, xc - 18f * s, xy - 18f * s, xc + 18f * s, xy + 18f * s, Pal.WHITE, 10f * s)
        Draw.line(c, xc - 18f * s, xy + 18f * s, xc + 18f * s, xy - 18f * s, Pal.WHITE, 10f * s)
    }

    // ------------------------------------------------------------ بازی
    private fun drawEq(c: Canvas, tokens: Array<String>, colors: IntArray, cx: Float, cy: Float, size: Float) {
        val gap = size * 0.28f
        var total = 0f
        for (tk in tokens) total += Draw.textWidth(tk, size)
        total += gap * (tokens.size - 1)
        var x = cx - total / 2f
        for (i in tokens.indices) {
            val w = Draw.textWidth(tokens[i], size)
            Draw.text(c, tokens[i], x + w / 2f, cy, size, colors[i], 0x33000000)
            x += w + gap
        }
    }

    private fun drawPlay(c: Canvas) {
        val q = cur ?: return
        val theme = 2 + (if (mode == 0) level else if (mode == 2) 3 else 7)
        drawBackground(c, theme)
        c.save()
        if (shake > 0f) c.translate((rnd.nextFloat() - 0.5f) * shake * 30f * s, (rnd.nextFloat() - 0.5f) * shake * 30f * s)
        val cx = W / 2f

        // نوار بالا
        btn(c, "pause", 30f * s, hudCy - 52f * s, 134f * s, hudCy + 52f * s + 14f * s, "", Pal.BLUE, Pal.BLUE_D, 10f)
        Draw.rect(c, 82f * s - 17f * s, hudCy - 22f * s, 82f * s - 5f * s, hudCy + 22f * s, 4f * s, Pal.WHITE)
        Draw.rect(c, 82f * s + 5f * s, hudCy - 22f * s, 82f * s + 17f * s, hudCy + 22f * s, 4f * s, Pal.WHITE)
        Draw.rect(c, cx - 190f * s, hudCy - 42f * s, cx + 190f * s, hudCy + 42f * s, 42f * s, withAlpha(black, 110))
        Draw.text(c, "امتیاز: ${fa(score)}", cx, hudCy, 46f * s, Pal.CREAM)
        if (mode != 1) {
            for (i in 0..2) {
                Draw.heart(c, W - 70f * s - i * 100f * s, hudCy, 86f * s, if (i < hearts) Pal.RED else withAlpha(Pal.WHITE, 60))
            }
        } else if (combo >= 2) {
            Draw.text(c, "کومبو ${fa(combo)}", W - 200f * s, hudCy, 46f * s, Pal.ORANGE)
        }
        val name = when (mode) {
            0 -> Art.monsterNames[level]
            2 -> "تمرین نقاط ضعف"
            else -> "مسابقه‌ی ${fa(60)} ثانیه"
        }
        Draw.text(c, name, cx, nameCy, 46f * s, Pal.CREAM)

        // جان دیو یا ساعت
        if (mode != 1) {
            val bw = 740f * s
            val bh = 36f * s
            Draw.rect(c, cx - bw / 2f, barCy - bh / 2f, cx + bw / 2f, barCy + bh / 2f, bh / 2f, withAlpha(black, 110))
            val frac = (monsterHp / maxHp.toFloat()).coerceIn(0f, 1f)
            if (frac > 0f) {
                Draw.rect(
                    c, cx - bw / 2f + 4f * s, barCy - bh / 2f + 4f * s,
                    cx - bw / 2f + 4f * s + (bw - 8f * s) * frac, barCy + bh / 2f - 4f * s, bh / 2f,
                    if (frac > 0.5f) Pal.GREEN else if (frac > 0.25f) Pal.GOLD else Pal.RED
                )
            }
        }
        if (mode == 1) {
            val rr = monR * 0.8f
            Draw.circle(c, cx, monCy, rr + 24f * s, withAlpha(black, 70))
            Draw.ring(c, cx, monCy, rr, withAlpha(Pal.WHITE, 70), 26f * s)
            val frac = (blitzLeft / 60f).coerceIn(0f, 1f)
            Draw.arc(c, cx, monCy, rr, -90f, 360f * frac, if (blitzLeft <= 10f) Pal.RED else Pal.GOLD, 26f * s)
            Draw.text(c, fa(ceil(blitzLeft).toInt()), cx, monCy, rr * 0.95f, Pal.WHITE)
        } else if (deadT < 1f) {
            Art.monster(c, cx, monCy, monR, monIdx(), tAll, hurtT.coerceIn(0f, 1f), attackT.coerceIn(0f, 1f), deadT)
        }

        // نوار زمان سؤال
        if (mode != 1) {
            val tw = 820f * s
            val th = 26f * s
            Draw.rect(c, cx - tw / 2f, timerCy - th / 2f, cx + tw / 2f, timerCy + th / 2f, th / 2f, withAlpha(black, 110))
            val frac = (qLeft / qMax).coerceIn(0f, 1f)
            if (frac > 0f) {
                Draw.rect(
                    c, cx - tw / 2f + 4f * s, timerCy - th / 2f + 4f * s,
                    cx - tw / 2f + 4f * s + (tw - 8f * s) * frac, timerCy + th / 2f - 4f * s, th / 2f,
                    if (frac > 0.5f) Pal.TURQ else if (frac > 0.25f) Pal.GOLD else Pal.RED
                )
            }
        }

        // کارت سؤال
        val cl = 70f * s
        val cr = W - 70f * s
        val border = if (phase == 0) Pal.GOLD else if (lastWasCorrect) Pal.GREEN else Pal.RED
        Draw.rect(c, cl, cardTop + 14f * s, cr, cardTop + cardH + 14f * s, 44f * s, withAlpha(black, 70))
        Draw.rect(c, cl, cardTop, cr, cardTop + cardH, 44f * s, Pal.CREAM)
        Draw.frame(c, cl + 10f * s, cardTop + 10f * s, cr - 10f * s, cardTop + cardH - 10f * s, 36f * s, border, 7f * s)
        Draw.girih(c, cl + 52f * s, cardTop + 52f * s, 26f * s, tAll * 20f, Pal.GOLD_D, 3f * s)
        Draw.girih(c, cr - 52f * s, cardTop + 52f * s, 26f * s, -tAll * 20f, Pal.GOLD_D, 3f * s)
        Draw.girih(c, cl + 52f * s, cardTop + cardH - 52f * s, 26f * s, -tAll * 20f, Pal.GOLD_D, 3f * s)
        Draw.girih(c, cr - 52f * s, cardTop + cardH - 52f * s, 26f * s, tAll * 20f, Pal.GOLD_D, 3f * s)

        val reveal = phase != 0
        val prod = fa(q.product)
        val tokens: Array<String>
        val cols: IntArray
        val ink = Pal.INK
        val op = Pal.GOLD_D
        val ask = Pal.PURPLE_D
        val good = Pal.GREEN_D
        when (q.type) {
            QType.MISSING -> {
                if (q.hidden == 0) {
                    tokens = arrayOf(if (reveal) fa(q.a) else "؟", "×", fa(q.b), "=", prod)
                    cols = intArrayOf(if (reveal) good else ask, op, ink, op, ink)
                } else {
                    tokens = arrayOf(fa(q.a), "×", if (reveal) fa(q.b) else "؟", "=", prod)
                    cols = intArrayOf(ink, op, if (reveal) good else ask, op, ink)
                }
            }
            QType.TF -> {
                tokens = arrayOf(fa(q.a), "×", fa(q.b), "=", fa(q.tfShown))
                cols = intArrayOf(ink, op, ink, op, if (!reveal) ink else if (q.tfTrue) good else Pal.RED_D)
            }
            else -> {
                tokens = arrayOf(fa(q.a), "×", fa(q.b), "=", if (reveal) prod else "؟")
                cols = intArrayOf(ink, op, ink, op, if (reveal) good else ask)
            }
        }
        val showTruth = reveal && q.type == QType.TF && !q.tfTrue
        if (showTruth) {
            drawEq(c, tokens, cols, cx, cardTop + 85f * s, 100f * s)
            drawEq(
                c, arrayOf(fa(q.a), "×", fa(q.b), "=", prod), intArrayOf(good, good, good, good, good),
                cx, cardTop + 170f * s, 60f * s
            )
        } else {
            drawEq(c, tokens, cols, cx, cardTop + cardH / 2f, 120f * s)
        }

        // پاسخ‌ها
        when (q.type) {
            QType.MC, QType.MISSING -> drawChoices(c, q)
            QType.TF -> drawTrueFalse(c, q)
            QType.TYPE -> drawKeypad(c, q)
        }

        // کمک‌ها
        val can5050 = phase == 0 && (q.type == QType.MC || q.type == QType.MISSING) && !q.used5050 && store.coins >= 15
        val canTime = phase == 0 && store.coins >= 10
        val pl = 80f * s
        val pr = W - 80f * s
        val pm = W / 2f
        val pcy = (powerTop + powerTop + powerH - 14f * s) / 2f
        btn(
            c, "pw5050", pl, powerTop, pm - 12f * s, powerTop + powerH, "حذف دو گزینه",
            if (can5050) Pal.PURPLE else Pal.GRAY, if (can5050) Pal.PURPLE_D else Pal.GRAY_D, 38f * s, can5050, 50f * s
        )
        Draw.coin(c, pm - 12f * s - 52f * s, pcy, 24f * s)
        Draw.text(c, fa(15), pm - 12f * s - 100f * s, pcy, 38f * s, Pal.WHITE, 0)
        btn(
            c, "pwtime", pm + 12f * s, powerTop, pr, powerTop + powerH, "+${fa(6)} ثانیه",
            if (canTime) Pal.TURQ else Pal.GRAY, if (canTime) Pal.TURQ_D else Pal.GRAY_D, 38f * s, canTime, 50f * s
        )
        Draw.coin(c, pr - 52f * s, pcy, 24f * s)
        Draw.text(c, fa(10), pr - 100f * s, pcy, 38f * s, Pal.WHITE, 0)

        c.restore()
        if (paused) drawPause(c)
    }

    private fun drawChoices(c: Canvas, q: Question) {
        val gap = 28f * s
        val tw = (W - 2f * 80f * s - gap) / 2f
        val th = min(210f * s, (ansBottom - ansTop - gap) / 2f)
        for (i in 0..3) {
            val col = i % 2
            val row = i / 2
            val l = 80f * s + col * (tw + gap)
            val t = ansTop + row * (th + gap)
            var fc = optCols[i]
            var fd = optColsD[i]
            if (q.disabled[i] && phase == 0) {
                fc = Pal.GRAY
                fd = Pal.GRAY_D
            }
            if (phase != 0) {
                if (i == q.correctIdx) {
                    fc = Pal.GREEN
                    fd = Pal.GREEN_D
                } else if (i == selected) {
                    fc = Pal.RED
                    fd = Pal.RED_D
                } else {
                    fc = Pal.GRAY
                    fd = Pal.GRAY_D
                }
            }
            btn(c, "opt$i", l, t, l + tw, t + th, fa(q.options[i]), fc, fd, 100f * s, phase == 0 && !q.disabled[i])
        }
    }

    private fun drawTrueFalse(c: Canvas, q: Question) {
        val gap = 28f * s
        val tw = (W - 2f * 80f * s - gap) / 2f
        val th = min(340f * s, ansBottom - ansTop)
        for (k in 0..1) {
            val yes = k == 1
            val l = 80f * s + (if (yes) tw + gap else 0f)
            var fc = if (yes) Pal.GREEN else Pal.RED
            var fd = if (yes) Pal.GREEN_D else Pal.RED_D
            if (phase != 0) {
                val isCorrectSide = yes == q.tfTrue
                val chosen = (selected == 1) == yes && selected >= 0
                if (isCorrectSide) {
                    fc = Pal.GREEN
                    fd = Pal.GREEN_D
                } else if (chosen) {
                    fc = Pal.RED
                    fd = Pal.RED_D
                } else {
                    fc = Pal.GRAY
                    fd = Pal.GRAY_D
                }
            }
            btn(c, if (yes) "tf1" else "tf0", l, ansTop, l + tw, ansTop + th, "", fc, fd, 10f, phase == 0)
            val icx = l + tw / 2f
            val icy = ansTop + (th - 14f * s) * 0.36f
            val z = 52f * s
            if (yes) {
                Draw.line(c, icx - z, icy, icx - z * 0.3f, icy + z * 0.75f, Pal.WHITE, 22f * s)
                Draw.line(c, icx - z * 0.3f, icy + z * 0.75f, icx + z, icy - z * 0.7f, Pal.WHITE, 22f * s)
            } else {
                Draw.line(c, icx - z * 0.8f, icy - z * 0.8f, icx + z * 0.8f, icy + z * 0.8f, Pal.WHITE, 22f * s)
                Draw.line(c, icx - z * 0.8f, icy + z * 0.8f, icx + z * 0.8f, icy - z * 0.8f, Pal.WHITE, 22f * s)
            }
            Draw.text(c, if (yes) "درسته" else "غلطه", icx, ansTop + (th - 14f * s) * 0.76f, 74f * s, Pal.WHITE)
        }
    }

    private fun drawKeypad(c: Canvas, q: Question) {
        val boxH = 120f * s
        val bl = 80f * s
        val br = W - 80f * s
        val bc = if (phase == 0) Pal.GOLD else if (lastWasCorrect) Pal.GREEN else Pal.RED
        Draw.rect(c, bl, ansTop, br, ansTop + boxH, 34f * s, Pal.CREAM)
        Draw.frame(c, bl + 6f * s, ansTop + 6f * s, br - 6f * s, ansTop + boxH - 6f * s, 28f * s, bc, 7f * s)
        val shown = if (typed.isEmpty()) {
            if (phase == 0 && ((tAll * 2f).toInt() % 2 == 0)) "|" else ""
        } else {
            fa(typed.toInt())
        }
        if (shown.isNotEmpty()) {
            Draw.text(c, shown, W / 2f, ansTop + boxH / 2f, 90f * s, if (phase == 0) Pal.INK else if (lastWasCorrect) Pal.GREEN_D else Pal.RED_D, 0)
        }
        val gap = 14f * s
        val kw = (br - bl - 2f * gap) / 3f
        val top = ansTop + boxH + 16f * s
        val kh = ((ansBottom - top - 3f * gap) / 4f).coerceIn(70f * s, 150f * s)
        for (r in 0..3) {
            for (col in 0..2) {
                val l = bl + col * (kw + gap)
                val t = top + r * (kh + gap)
                val id: String
                val label: String
                var fc = Pal.BLUE
                var fd = Pal.BLUE_D
                if (r < 3) {
                    val d = r * 3 + col + 1
                    id = "key$d"
                    label = fa(d)
                } else when (col) {
                    0 -> {
                        id = "del"
                        label = ""
                        fc = Pal.ORANGE
                        fd = Pal.ORANGE_D
                    }
                    1 -> {
                        id = "key0"
                        label = fa(0)
                    }
                    else -> {
                        id = "ok"
                        label = ""
                        fc = Pal.GREEN
                        fd = Pal.GREEN_D
                    }
                }
                val en = phase == 0
                if (!en) {
                    fc = Pal.GRAY
                    fd = Pal.GRAY_D
                }
                btn(c, id, l, t, l + kw, t + kh, label, fc, fd, 70f * s, en)
                val icx = l + kw / 2f
                val icy = t + (kh - 14f * s) / 2f
                val z = min(kh * 0.22f, 34f * s)
                if (id == "ok") {
                    Draw.line(c, icx - z, icy, icx - z * 0.3f, icy + z * 0.8f, Pal.WHITE, 12f * s)
                    Draw.line(c, icx - z * 0.3f, icy + z * 0.8f, icx + z, icy - z * 0.7f, Pal.WHITE, 12f * s)
                } else if (id == "del") {
                    Draw.line(c, icx + z, icy, icx - z, icy, Pal.WHITE, 12f * s)
                    Draw.line(c, icx - z, icy, icx - z * 0.2f, icy - z * 0.8f, Pal.WHITE, 12f * s)
                    Draw.line(c, icx - z, icy, icx - z * 0.2f, icy + z * 0.8f, Pal.WHITE, 12f * s)
                }
            }
        }
    }

    private fun drawPause(c: Canvas) {
        hits.clear()
        c.drawColor(withAlpha(black, 170))
        val cx = W / 2f
        Draw.text(c, "توقف", cx, H * 0.27f, 130f * s, Pal.GOLD)
        val bw = 760f * s
        val bh = 140f * s
        var y = H * 0.38f
        btn(c, "resume", cx - bw / 2f, y, cx + bw / 2f, y + bh, "ادامه", Pal.GREEN, Pal.GREEN_D, 64f * s)
        y += bh + 36f * s
        btn(c, "restart", cx - bw / 2f, y, cx + bw / 2f, y + bh, "شروع دوباره", Pal.ORANGE, Pal.ORANGE_D, 58f * s)
        y += bh + 36f * s
        btn(c, "quit", cx - bw / 2f, y, cx + bw / 2f, y + bh, "خروج", Pal.RED, Pal.RED_D, 58f * s)
    }

    // ------------------------------------------------------------ نتیجه
    private fun drawResult(c: Canvas) {
        val th = if (mode == 0) 2 + level else if (mode == 2) 5 else 9
        drawBackground(c, if (resWin) th else 0)
        val cx = W / 2f
        val title = if (mode == 1) "پایان مسابقه!" else if (resWin) "پیروز شدی!" else "دوباره تلاش کن!"
        Draw.girih(c, cx, H * 0.255f, 400f * s, tAll * 8f, withAlpha(Pal.GOLD, 70), 5f * s)
        Draw.text(c, title, cx, H * 0.135f, Draw.fit(title, 120f * s, 900f * s), if (resWin) Pal.GOLD else Pal.CREAM)

        if (mode == 1) {
            Draw.circle(c, cx, H * 0.26f, 190f * s, Pal.GOLD_D)
            Draw.circle(c, cx, H * 0.26f, 170f * s, Pal.GOLD)
            Draw.text(c, fa(resScore), cx, H * 0.26f - 20f * s, Draw.fit(fa(resScore), 130f * s, 280f * s), Pal.INK, 0)
            Draw.text(c, "امتیاز", cx, H * 0.26f + 85f * s, 46f * s, Pal.BROWN, 0)
        } else if (resWin) {
            for (i in 0..2) {
                val sx = cx + (i - 1) * 230f * s
                val sy = H * 0.255f + (if (i == 1) -30f * s else 0f)
                val tt = resT - (0.7f + 0.5f * i)
                if (i < resStars && tt >= 0f) {
                    val sc = min(1f, tt / 0.2f) * (1f + 0.35f * max(0f, 1f - tt / 0.35f))
                    Draw.star(c, sx, sy + 8f * s, 110f * s * sc, 50f * s * sc, 5, 0f, Pal.GOLD_D)
                    Draw.star(c, sx, sy, 110f * s * sc, 50f * s * sc, 5, 0f, Pal.GOLD)
                } else {
                    Draw.star(c, sx, sy, 110f * s, 50f * s, 5, 0f, withAlpha(Pal.WHITE, 60))
                }
            }
        } else {
            Art.monster(c, cx, H * 0.27f, 150f * s, monIdx(), tAll, 0f, 0.5f, 0f)
        }

        val cl = 90f * s
        val cr = W - 90f * s
        val ct = H * 0.40f
        val rowH = 112f * s
        val rows = 4
        val cb = ct + rowH * rows + 40f * s
        Draw.rect(c, cl, ct + 12f * s, cr, cb + 12f * s, 44f * s, withAlpha(black, 70))
        Draw.rect(c, cl, ct, cr, cb, 44f * s, Pal.CREAM)
        Draw.frame(c, cl + 10f * s, ct + 10f * s, cr - 10f * s, cb - 10f * s, 36f * s, Pal.GOLD, 7f * s)
        val labels: Array<String>
        val values: Array<String>
        if (mode == 1) {
            labels = arrayOf("پاسخ درست", "بیشترین کومبو", "سکه‌ی جایزه", "رکورد")
            values = arrayOf(fa(resCorrect), fa(resCombo), fa(resCoins), fa(resBest))
        } else {
            labels = arrayOf("امتیاز", "پاسخ درست", "بیشترین کومبو", "سکه‌ی جایزه")
            values = arrayOf(fa(resScore), fa(resCorrect), fa(resCombo), fa(resCoins))
        }
        for (i in 0 until rows) {
            val y = ct + 20f * s + rowH * (i + 0.5f)
            Draw.text(c, labels[i], cr - 56f * s, y, 52f * s, Pal.INK, 0, Paint.Align.RIGHT)
            Draw.text(c, values[i], cl + 56f * s, y, 58f * s, Pal.TURQ_D, 0, Paint.Align.LEFT)
        }
        if (mode == 1 && resNewBest && resScore > 0) {
            Draw.text(c, "رکورد جدید!", cx, cb + 70f * s, 68f * s + sin(tAll * 8f) * 4f * s, Pal.GOLD)
        }

        val bw = 760f * s
        val bh = 130f * s
        var y = cb + 130f * s
        if (resWin && mode == 0 && level < 8) {
            btn(c, "r_next", cx - bw / 2f, y, cx + bw / 2f, y + bh, "مرحله‌ی بعد", Pal.GREEN, Pal.GREEN_D, 58f * s)
            y += bh + 26f * s
        }
        btn(c, "r_again", cx - bw / 2f, y, cx + bw / 2f, y + bh, "دوباره", Pal.ORANGE, Pal.ORANGE_D, 56f * s)
        y += bh + 26f * s
        btn(c, "r_back", cx - bw / 2f, y, cx + bw / 2f, y + bh, if (mode == 0) "نقشه" else "منوی اصلی", Pal.BLUE, Pal.BLUE_D, 56f * s)
    }

    // ------------------------------------------------------------ دفتر مشق
    private fun drawGrid(c: Canvas) {
        drawBackground(c, 1)
        Draw.text(c, "دفتر مشق", W / 2f, topPad + 60f * s, 80f * s, Pal.BROWN, 0x33FFFFFF)
        backButton(c)

        val cell = 98f * s
        val gap = 8f * s
        val gw = 9f * cell + 8f * gap
        val left = (W - gw) / 2f
        val top = topPad + 190f * s

        // سرستون‌ها
        Draw.rect(c, left, top, left + cell, top + cell, 16f * s, Pal.BROWN)
        Draw.text(c, "×", left + cell / 2f, top + cell / 2f, 56f * s, Pal.WHITE, 0)
        for (k in 0..7) {
            val v = k + 2
            val x = left + (k + 1) * (cell + gap)
            Draw.rect(c, x, top, x + cell, top + cell, 16f * s, Pal.TURQ_D)
            Draw.text(c, fa(v), x + cell / 2f, top + cell / 2f, 52f * s, Pal.WHITE, 0)
            val y = top + (k + 1) * (cell + gap)
            Draw.rect(c, left, y, left + cell, y + cell, 16f * s, Pal.TURQ_D)
            Draw.text(c, fa(v), left + cell / 2f, y + cell / 2f, 52f * s, Pal.WHITE, 0)
        }
        val unseen = 0xFFE8D5A8.toInt()
        for (r in 0..7) {
            for (cc in 0..7) {
                val a = r + 2
                val b = cc + 2
                val cor = store.correct(a, b)
                val wr = store.wrong(a, b)
                val col = when {
                    cor + wr == 0 -> unseen
                    wr > cor -> Pal.RED
                    cor >= 3 && cor >= 2 * wr -> Pal.GREEN
                    else -> Pal.GOLD
                }
                val x = left + (cc + 1) * (cell + gap)
                val y = top + (r + 1) * (cell + gap)
                Draw.rect(c, x, y, x + cell, y + cell, 16f * s, col)
                Draw.text(c, fa(a * b), x + cell / 2f, y + cell / 2f, 40f * s, if (cor + wr == 0) withAlpha(Pal.BROWN, 170) else Pal.WHITE, 0)
            }
        }

        var mastered = 0
        for (a in 2..9) {
            for (b in a..9) {
                val cr = store.correct(a, b)
                val w = store.wrong(a, b)
                if (cr >= 3 && cr >= 2 * w) mastered++
            }
        }
        val pct = mastered * 100 / 36
        val gb = top + 9f * (cell + gap)
        Draw.text(c, "تسلط شما: ${fa(pct)}٪", W / 2f, gb + 50f * s, 60f * s, Pal.BROWN, 0x33FFFFFF)
        Draw.text(c, "پاسخ درست: ${fa(store.totalCorrect)} از ${fa(store.totalAnswered)}", W / 2f, gb + 125f * s, 42f * s, Pal.INK, 0)

        // راهنمای رنگ‌ها
        val names = arrayOf("دیده‌نشده", "ضعیف", "در حال یادگیری", "مسلط")
        val lcols = intArrayOf(unseen, Pal.RED, Pal.GOLD, Pal.GREEN)
        for (i in 0..3) {
            val lx = W * (0.125f + 0.25f * i)
            Draw.rect(c, lx - 22f * s, gb + 190f * s, lx + 22f * s, gb + 234f * s, 10f * s, lcols[i])
            Draw.text(c, names[i], lx, gb + 270f * s, Draw.fit(names[i], 34f * s, W * 0.23f), Pal.INK, 0)
        }

        val bw = 780f * s
        val by = gb + 340f * s
        btn(c, "weak", W / 2f - bw / 2f, by, W / 2f + bw / 2f, by + 140f * s, "تمرین نقاط ضعف", Pal.GREEN, Pal.GREEN_D, 58f * s)
    }

    // ------------------------------------------------------------ درباره / طراح و سازنده
    private fun drawAbout(c: Canvas) {
        drawBackground(c, 0)
        val cx = W / 2f
        Draw.girih(c, cx, H * 0.46f, 640f * s, tAll * 4f, withAlpha(Pal.GOLD, 60), 6f * s)
        Draw.girih(c, cx, H * 0.46f, 500f * s, -tAll * 6f, withAlpha(Pal.TURQ, 60), 5f * s)
        backButton(c)

        val l = 80f * s
        val r = W - 80f * s
        val t = H * 0.17f
        val b = H * 0.75f
        Draw.rect(c, l, t + 14f * s, r, b + 14f * s, 50f * s, withAlpha(black, 90))
        Draw.rect(c, l, t, r, b, 50f * s, withAlpha(Pal.NIGHT1, 235))
        Draw.frame(c, l + 14f * s, t + 14f * s, r - 14f * s, b - 14f * s, 40f * s, Pal.GOLD, 8f * s)

        val h = b - t
        Draw.text(c, "ضرب‌ستان", cx, t + h * 0.10f, Draw.fit("ضرب‌ستان", 120f * s, 800f * s), Pal.GOLD, Pal.ORANGE_D)
        for (k in -2..2) {
            Draw.girih(c, cx + k * 110f * s, t + h * 0.20f, 34f * s, tAll * 30f * (if (k % 2 == 0) 1f else -1f), Pal.GOLD, 3f * s)
        }
        Draw.text(c, "بازی آموزشی جدول ضرب", cx, t + h * 0.30f, 54f * s, Pal.WHITE)
        Draw.text(c, "مخصوص پایه‌ی سوم دبستان", cx, t + h * 0.37f, 44f * s, Pal.CREAM)

        Draw.line(c, l + 120f * s, t + h * 0.45f, r - 120f * s, t + h * 0.45f, withAlpha(Pal.GOLD, 160), 4f * s)

        Draw.text(c, "طراح و سازنده", cx, t + h * 0.54f, 56f * s, Pal.TURQ)
        val nm = "شاهین شیخ کانلو"
        Draw.text(c, nm, cx, t + h * 0.65f, Draw.fit(nm, 118f * s, 800f * s), Pal.GOLD, Pal.ORANGE_D)

        Draw.line(c, l + 120f * s, t + h * 0.75f, r - 120f * s, t + h * 0.75f, withAlpha(Pal.GOLD, 160), 4f * s)
        Draw.text(c, "ساخته‌شده با عشق برای", cx, t + h * 0.82f, 42f * s, Pal.CREAM, 0)
        Draw.text(c, "یادگیری شاد جدول ضرب", cx, t + h * 0.88f, 42f * s, Pal.CREAM, 0)
        Draw.text(c, "نسخه ${fa(1)}.${fa(0)}", cx, t + h * 0.95f - 6f * s, 34f * s, Pal.GRAY, 0)
    }

    // ------------------------------------------------------------ ذرات و نوشته‌های شناور
    private fun drawFx(c: Canvas) {
        for (p in parts) {
            val k = p.age / p.life
            val a = (255f * (if (k < 0.7f) 1f else (1f - k) / 0.3f)).toInt()
            val col = withAlpha(p.color, a)
            when (p.kind) {
                0 -> Draw.circle(c, p.x, p.y, p.size * 0.5f * (1f - k * 0.5f), col)
                1 -> Draw.star(c, p.x, p.y, p.size, p.size * 0.45f, 5, p.rot, col)
                2 -> {
                    c.save()
                    c.translate(p.x, p.y)
                    c.rotate(p.rot)
                    Draw.rect(c, -p.size / 2f, -p.size / 4f, p.size / 2f, p.size / 4f, 2f * s, col)
                    c.restore()
                }
                else -> {
                    val sq = max(0.15f, abs(cos(p.rot * 0.05f)))
                    Draw.oval(c, p.x, p.y, p.size * 0.6f * sq, p.size * 0.6f, withAlpha(Pal.GOLD_D, a))
                    Draw.oval(c, p.x, p.y, p.size * 0.42f * sq, p.size * 0.42f, col)
                }
            }
        }
        for (f in ftexts) {
            val k = f.age / 1.2f
            val a = (255f * (if (k < 0.6f) 1f else (1f - k) / 0.4f)).toInt()
            val pop = 1f + 0.25f * max(0f, 1f - f.age / 0.2f)
            Draw.text(c, f.text, f.x, f.y, f.size * pop, withAlpha(f.color, a), withAlpha(black, a / 2))
        }
    }
}
