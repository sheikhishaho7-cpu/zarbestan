package ir.shahin.zarbestan

import android.graphics.Canvas
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/** شخصیت‌ها: شتر کاروان و دیوهای هر شهر (همه با کد کشیده می‌شوند) */
object Art {

    val monsterNames = arrayOf(
        "دیو خواب‌آلود", "دیو شیطون", "دیو قلدر", "دیو یک‌چشم", "دیو عصبانی",
        "دیو شکمو", "دیو ترسناک", "دیو آتشین", "شاه دیوها", "دیو بدقلق"
    )

    private val monPal = arrayOf(
        intArrayOf(0xFF6BCB77.toInt(), 0xFF3C9A4B.toInt(), 0xFFD4F7D0.toInt()),
        intArrayOf(0xFFFF8FAB.toInt(), 0xFFD6577C.toInt(), 0xFFFFE0E9.toInt()),
        intArrayOf(0xFF4CC9F0.toInt(), 0xFF2A8CB8.toInt(), 0xFFD2F3FF.toInt()),
        intArrayOf(0xFFFFB347.toInt(), 0xFFD9822B.toInt(), 0xFFFFE8C4.toInt()),
        intArrayOf(0xFFEF476F.toInt(), 0xFFA82446.toInt(), 0xFFFFD1DC.toInt()),
        intArrayOf(0xFF9B72FF.toInt(), 0xFF6240C9.toInt(), 0xFFE4DAFF.toInt()),
        intArrayOf(0xFF5E60CE.toInt(), 0xFF3A3B9A.toInt(), 0xFFD6D7FF.toInt()),
        intArrayOf(0xFFFF6B35.toInt(), 0xFFB33A12.toInt(), 0xFFFFD9C7.toInt()),
        intArrayOf(0xFFF0F0F5.toInt(), 0xFFAEB6CB.toInt(), 0xFFFFFFFF.toInt()),
        intArrayOf(0xFF9C7B6B.toInt(), 0xFF5D4037.toInt(), 0xFFD7CCC8.toInt())
    )

    /**
     * دیو. hurt: ضربه خوردن (۰..۱)، attack: حمله (۰..۱)، dead: شکست (۰..۱)
     */
    fun monster(
        c: Canvas, cx: Float, cy: Float, r: Float, idx: Int, t: Float,
        hurt: Float, attack: Float, dead: Float
    ) {
        val p = monPal[idx.coerceIn(0, monPal.size - 1)]
        val main = mix(p[0], Pal.WHITE, hurt * 0.75f)
        val dark = p[1]
        val belly = p[2]
        c.save()
        val bob = sin(t * 2.4f) * r * 0.035f
        c.translate(cx, cy + bob + attack * r * 0.16f)
        c.rotate(sin(t * 1.6f) * 2.5f + dead * 540f)
        val sc = (1f + attack * 0.2f) * (1f - dead)
        c.scale(sc, sc)
        if (hurt > 0f) c.translate(sin(t * 80f) * r * 0.06f * hurt, 0f)

        // سایه و پاها
        Draw.oval(c, 0f, r * 1.02f, r * 0.8f, r * 0.12f, 0x33000000)
        Draw.oval(c, -r * 0.4f, r * 0.95f, r * 0.26f, r * 0.14f, dark)
        Draw.oval(c, r * 0.4f, r * 0.95f, r * 0.26f, r * 0.14f, dark)

        // دست‌ها
        val wave = sin(t * 3f) * r * 0.08f + attack * r * 0.3f
        Draw.oval(c, -r * 1.02f, r * 0.2f - wave, r * 0.24f, r * 0.2f, dark)
        Draw.oval(c, r * 1.02f, r * 0.2f - wave, r * 0.24f, r * 0.2f, dark)

        // شاخ‌ها
        val horns = 2 + idx % 3
        for (i in 0 until horns) {
            val a = if (horns == 1) 0f else -50f + 100f * i / (horns - 1)
            val ar = Math.toRadians(a.toDouble())
            val dx = sin(ar).toFloat()
            val dy = (-cos(ar)).toFloat()
            val bx = dx * r * 0.86f
            val by = dy * r * 0.86f
            val tx = bx + dx * r * 0.55f
            val ty = by + dy * r * 0.55f
            val px = -dy * r * 0.15f
            val py = dx * r * 0.15f
            Draw.tri(c, bx - px, by - py, bx + px, by + py, tx, ty, 0xFFFFF0C2.toInt())
            Draw.tri(c, bx - px * 0.4f + dx * r * 0.3f, by - py * 0.4f + dy * r * 0.3f,
                bx + px * 0.4f + dx * r * 0.3f, by + py * 0.4f + dy * r * 0.3f, tx, ty, 0xFFE0B96A.toInt())
        }

        // بدن
        Draw.circle(c, 0f, 0f, r, main)
        Draw.ring(c, 0f, 0f, r * 0.97f, dark, r * 0.06f)
        Draw.oval(c, 0f, r * 0.4f, r * 0.62f, r * 0.5f, belly)

        // خال‌های بدن
        Draw.circle(c, -r * 0.55f, -r * 0.5f, r * 0.08f, withAlpha(dark, 150))
        Draw.circle(c, r * 0.62f, -r * 0.35f, r * 0.06f, withAlpha(dark, 150))
        Draw.circle(c, r * 0.35f, -r * 0.72f, r * 0.05f, withAlpha(dark, 150))

        // چشم‌ها
        val cyclops = idx % 4 == 3
        val ex = if (cyclops) floatArrayOf(0f) else floatArrayOf(-r * 0.36f, r * 0.36f)
        val er = if (cyclops) r * 0.34f else r * 0.24f
        val ey = -r * 0.2f
        for (x in ex) {
            Draw.circle(c, x, ey, er, 0xFFFFFFFF.toInt())
            Draw.ring(c, x, ey, er, dark, r * 0.03f)
            if (hurt > 0.3f) {
                val k = er * 0.5f
                Draw.line(c, x - k, ey - k, x + k, ey + k, 0xFF2B1B40.toInt(), r * 0.05f)
                Draw.line(c, x - k, ey + k, x + k, ey - k, 0xFF2B1B40.toInt(), r * 0.05f)
            } else {
                val px = sin(t * 1.3f) * er * 0.25f
                val py = cos(t * 0.9f) * er * 0.15f + attack * er * 0.2f
                Draw.circle(c, x + px, ey + py, er * 0.5f, 0xFF2B1B40.toInt())
                Draw.circle(c, x + px - er * 0.15f, ey + py - er * 0.18f, er * 0.16f, 0xFFFFFFFF.toInt())
            }
            // ابروی عصبانی
            val sgn = if (x < 0f) 1f else -1f
            if (cyclops) {
                Draw.line(c, x - er, ey - er * 1.25f, x + er, ey - er * 1.0f, dark, r * 0.07f)
            } else {
                Draw.line(c, x - sgn * er * 1.1f, ey - er * 1.5f, x + sgn * er * 0.9f, ey - er * 1.05f, dark, r * 0.07f)
            }
        }

        // دهان
        val my = r * 0.28f
        if (attack > 0.3f || hurt > 0.3f) {
            Draw.oval(c, 0f, my + r * 0.05f, r * 0.26f, r * 0.24f, 0xFF3B1226.toInt())
            Draw.oval(c, 0f, my + r * 0.16f, r * 0.14f, r * 0.1f, 0xFFFF6B81.toInt())
        } else {
            Draw.oval(c, 0f, my, r * 0.46f, r * 0.2f, 0xFF3B1226.toInt())
            val teeth = 3 + idx % 3
            val tw = r * 0.76f / teeth
            for (i in 0 until teeth) {
                val x0 = -r * 0.38f + i * tw
                Draw.tri(c, x0 + tw * 0.08f, my - r * 0.17f, x0 + tw * 0.92f, my - r * 0.17f, x0 + tw * 0.5f, my + r * 0.04f, 0xFFFFFFFF.toInt())
            }
            Draw.oval(c, 0f, my + r * 0.12f, r * 0.17f, r * 0.07f, 0xFFFF6B81.toInt())
        }

        // گونه‌ها
        Draw.circle(c, -r * 0.62f, r * 0.12f, r * 0.1f, withAlpha(0xFFFF6B81.toInt(), 110))
        Draw.circle(c, r * 0.62f, r * 0.12f, r * 0.1f, withAlpha(0xFFFF6B81.toInt(), 110))

        // تاج برای شاه دیوها
        if (idx == 8) {
            val cy0 = -r * 0.95f
            Draw.tri(c, -r * 0.5f, cy0, -r * 0.5f, cy0 - r * 0.42f, -r * 0.25f, cy0 - r * 0.15f, Pal.GOLD)
            Draw.tri(c, -r * 0.3f, cy0, 0f, cy0 - r * 0.6f, r * 0.3f, cy0, Pal.GOLD)
            Draw.tri(c, r * 0.5f, cy0, r * 0.5f, cy0 - r * 0.42f, r * 0.25f, cy0 - r * 0.15f, Pal.GOLD)
            Draw.rect(c, -r * 0.5f, cy0 - r * 0.02f, r * 0.5f, cy0 + r * 0.13f, r * 0.03f, Pal.GOLD_D)
            Draw.circle(c, 0f, cy0 - r * 0.46f, r * 0.06f, Pal.RED)
            Draw.circle(c, 0f, cy0 + r * 0.055f, r * 0.05f, Pal.TURQ)
        }
        c.restore()
    }

    /** شتر دوکوهانه‌ی کاروان. flip=true یعنی رو به چپ */
    fun camel(c: Canvas, x: Float, y: Float, k: Float, t: Float, walk: Boolean, flip: Boolean) {
        c.save()
        c.translate(x, y)
        c.scale(if (flip) -k else k, k)
        val sw = if (walk) sin(t * 7f) else 0f
        val bob = if (walk) abs(sin(t * 7f)) * 5f else sin(t * 2f) * 2f
        val body = 0xFFD9A25E.toInt()
        val bodyD = 0xFFB5803F.toInt()
        Draw.oval(c, 0f, 0f, 125f, 14f, 0x33000000)
        // پاهای دورتر
        Draw.line(c, -70f, -90f - bob, -70f - sw * 28f, 0f, bodyD, 24f)
        Draw.line(c, 70f, -90f - bob, 70f + sw * 28f, 0f, bodyD, 24f)
        // دم
        Draw.line(c, -108f, -135f - bob, -128f, -92f - bob, bodyD, 10f)
        // بدن و کوهان‌ها
        Draw.oval(c, 0f, -125f - bob, 112f, 58f, body)
        Draw.oval(c, -48f, -182f - bob, 38f, 46f, body)
        Draw.oval(c, 38f, -182f - bob, 38f, 46f, body)
        // پتوی رنگی
        Draw.rect(c, -80f, -150f - bob, 78f, -104f - bob, 10f, Pal.RED)
        Draw.rect(c, -80f, -132f - bob, 78f, -122f - bob, 0f, Pal.GOLD)
        Draw.circle(c, -60f, -88f - bob, 9f, Pal.TURQ)
        Draw.circle(c, -20f, -88f - bob, 9f, Pal.GOLD)
        Draw.circle(c, 20f, -88f - bob, 9f, Pal.TURQ)
        Draw.circle(c, 60f, -88f - bob, 9f, Pal.GOLD)
        // پاهای نزدیک‌تر
        Draw.line(c, -40f, -85f - bob, -40f + sw * 28f, 0f, body, 26f)
        Draw.line(c, 100f, -95f - bob, 100f - sw * 28f, 0f, body, 26f)
        // گردن و سر
        Draw.line(c, 88f, -150f - bob, 140f, -250f - bob, body, 42f)
        Draw.oval(c, 168f, -262f - bob, 46f, 27f, body)
        Draw.oval(c, 200f, -255f - bob, 18f, 17f, bodyD)
        Draw.circle(c, 160f, -270f - bob, 8f, 0xFFFFFFFF.toInt())
        Draw.circle(c, 162f, -270f - bob, 4.5f, 0xFF2B1B40.toInt())
        Draw.oval(c, 140f, -292f - bob, 9f, 14f, bodyD)
        // افسار
        Draw.line(c, 150f, -250f - bob, 205f, -250f - bob, Pal.RED, 5f)
        c.restore()
    }
}
