plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "ir.shahin.zarbestan"
    compileSdk = 35

    defaultConfig {
        applicationId = "ir.shahin.zarbestan"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

// عمداً هیچ کتابخانه‌ی اضافه‌ای استفاده نشده است؛ همه‌ی گرافیک و صدا با کد ساخته می‌شود.
